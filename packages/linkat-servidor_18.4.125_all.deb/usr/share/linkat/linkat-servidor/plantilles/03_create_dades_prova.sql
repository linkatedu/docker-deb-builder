use JClicReports;

\. jclic_test_mysql.sql


