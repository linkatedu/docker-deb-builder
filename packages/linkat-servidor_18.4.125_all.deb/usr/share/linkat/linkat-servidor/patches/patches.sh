#!/bin/bash

cd /usr/share/linkat/linkat-servidor/patches/

./01-nextcloud.sh
./02-smb.sh
